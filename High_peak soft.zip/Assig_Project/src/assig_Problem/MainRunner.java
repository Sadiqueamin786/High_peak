package assig_Problem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
class Item {
	  String name;
	  int price;
	  
	  public Item(String name, int price) {
	    this.name = name;
	    this.price = price;
	  }
	  
	  public String toString() { 
	      return this.name + ": " + this.price;
	  }
}

public class MainRunner {
	
		

	public static void main(String[] args) throws IOException {
		String path="C:\\Users\\Sadique amin\\eclipse-workspace\\Assig_Project\\src\\assig_Problem";
		File file = new File(path+"\\sample_input.txt");
		
		 Scanner sc=new Scanner(file);
		 int number_of_employees = Integer.parseInt(sc.nextLine().split(": ")[1]);
		 sc.nextLine(); sc.nextLine();sc.nextLine(); 
		 
		 ArrayList<Item> goodies_items = new ArrayList<Item>();
		 while(sc.hasNextLine())  
		    {
		      String current[] = sc.nextLine().split(": ");
		      goodies_items.add(new Item(current[0], Integer.parseInt(current[1])));
		     
		    }
		    sc.close();
		    Collections.sort(goodies_items, new Comparator<Item>(){
			      public int compare(Item a, Item b) { 
			        return a.price - b.price; 
			      } 
			    });
		    int min_diff = goodies_items.get(goodies_items.size()-1).price;
		    int min_index = 0;
		    for(int i=0;i<goodies_items.size()-number_of_employees+1;i++) {
		      int diff = goodies_items.get(number_of_employees+i-1).price-goodies_items.get(i).price;
		      
		      if(diff<=min_diff) {
		        min_diff = diff;
		        min_index = i;
		      }
		    }
		    FileWriter fw = new FileWriter(path+"\\output_3.txt");
		    fw.write("The goodies selected for distribution are:\n\n");
		    for(int i=min_index;i<min_index + number_of_employees; i++) {
		    	
		      fw.write(goodies_items.get(i).toString() + "\n");
		    }
		    
		    fw.write("\nAnd the difference between the chosen goodie with highest price and the lowest price is " + min_diff);
			  fw.close();
		  }
		
		
	}
		
		
		 


